from django.apps import AppConfig


class QuotedashAppConfig(AppConfig):
    name = 'quoteDash_app'
